class Graph:

    def __init__(self, isp, graph):
        self.isp = isp
        self.graph = graph
