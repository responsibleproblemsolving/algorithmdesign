class Solution:
    
    def __init__(self, listOfRallies):
        self.rallies = listOfRallies
    
    def getSchedule(self):
        ################# YOUR CODE GOES HERE ##################
        return []
