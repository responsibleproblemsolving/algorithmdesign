#include <vector>
#include <algorithm>

using namespace std;
class Solution
{
    public:
        Solution(vector<pair<int,int>>);
        vector<pair<int,int>> rallies;
        vector<pair<int,int>> outputRallies();
};

Solution::Solution(vector<pair<int,int>> _rallies)
{
	rallies = _rallies;
}

/** Implement the solution in this function
 * Return a vector of pairs of int containing the Rally ID and start time of the schedule you computed
 * or an empty vector of pairs of int if there exists no valid schedule and Serena has to take the nuke option.
 *
 * Don't change any files but this one!
 */
vector<pair<int,int>> Solution::outputRallies()
{
    std::vector<std::pair<int,int>> schedule;
    
    return schedule;
}
